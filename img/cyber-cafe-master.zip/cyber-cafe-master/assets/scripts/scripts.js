const sha1 = require('sha1');
const SerialPort = require("serialport");

const webFrame = document.getElementById('web-frame');
const loader = document.getElementById('loader');
// const browserClose = document.getElementById('browser-close');

const casinoButton = document.getElementById('casino');

let ultimoImporte;

let cierreForzado = true;


let accesoCasino = false;
let primerAccesoCasino = true;

let cantidadErrores = 0;

// links
const googleLink = document.getElementById('google');
const facebookLink = document.getElementById('facebook');
const twitterLink = document.getElementById('twitter');
const instagramLink = document.getElementById('instagram');
const youtubeLink = document.getElementById('youtube');
const spotifyLink = document.getElementById('spotify');
const netflixLink = document.getElementById('netflix');
const messengerLink = document.getElementById('messenger');
const pinterstLink = document.getElementById('pinterest');
const tumblrLink = document.getElementById('tumblr');
const yahooLink = document.getElementById('yahoo');
const gmailLink = document.getElementById('gmail');
const bingLink = document.getElementById('bing');
const wikipediaLink = document.getElementById('wikipedia');
const outlookLink = document.getElementById('outlook');

const bloqueTimer = document.getElementById('bloque-timer');

let session;
let saldo;

let balance;

let timerEmpezado = false;

let links = JSON.parse(window.sessionStorage.getItem('links'));

let rate = window.sessionStorage.getItem('rate');

saldoLocal = Number(window.sessionStorage.getItem('saldoLocal'));

let linksLocales = ['http://www.youtube.com', 'http://www.facebook.com', 'https://www.messenger.com/', 'http://www.twitter.com', 'http://www.instagram.com', 'http://www.youtube.com', 'http://www.spotify.com', 'http://www.netflix.com', 'http://www.pinterest.com', 'http://www.tumblr.com', 'http://www.yahoo.com', 'http://www.gmail.com', 'http://www.bing.com', 'http://www.wikipedia.com', 'http://www.outlook.com']


function setLinks(){
    if (links != null){
        // Set Imagenes
        document.getElementById('google-img').src = links[0].icon;
        document.getElementById('facebook-img').src = links[1].icon;
        document.getElementById('messenger-img').src = links[2].icon;
        document.getElementById('twitter-img').src = links[3].icon;
        document.getElementById('instagram-img').src = links[4].icon;
        document.getElementById('youtube-img').src = links[5].icon;
        document.getElementById('spotify-img').src = links[6].icon;
        document.getElementById('netflix-img').src = links[7].icon;
        document.getElementById('pinterest').src = links[8].icon;
        document.getElementById('tumblr-img').src = links[9].icon;
        document.getElementById('yahoo-img').src = links[10].icon;
        document.getElementById('gmail-img').src = links[11].icon;
        document.getElementById('bing-img').src = links[12].icon;
        document.getElementById('wikipedia-img').src = links[13].icon;
        document.getElementById('outlook-img').src = links[14].icon;

        // SET LINKS
        for (let i = 0; i <15; i++) {
            linksLocales[i] = links[i].link
        }

    }
}

setLinks();

function actualizarSaldoLocal(q){
    window.sessionStorage.setItem('saldoLocal', (saldoLocal * 10 + q * 10) / 10);
    saldoLocal = parseFloat(window.sessionStorage.getItem('saldoLocal'));
    if ( document.getElementById('saldo-restante') !== null){
        document.getElementById('saldo-restante').innerHTML = saldoLocal
    }
}

/*function restarSaldoLocal(q){
    window.sessionStorage.setItem('saldoLocal', (saldoLocal * 10 - q * 10) / 10);
    saldoLocal = parseFloat(window.sessionStorage.getItem('saldoLocal'));
    if ( document.getElementById('saldo-restante') !== null){
        document.getElementById('saldo-restante').innerHTML = saldoLocal;
    }
}*/


function emparejarBalance(){
    if (primerAccesoCasino === true){
        cashIn(saldoLocal);
        setTimeout(actualizarBalance, 3000);
    } else {
        if (saldoLocal > balance){
            setTimeout(cashIn, 2000, saldoLocal - balance);
        }
    }
}


// API

let user = "k00m01";
let pass = "1q2w3e4r";
let token;
let casinoUrl;

// login();

function login(){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/Login';
    Http.open("POST", url);
    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4){
            const response = JSON.parse(Http.responseText);
            console.log(pass+user+year+month+day+hour+min);
            console.log(response)
            if (response.status === 200){
                casinoButton.classList.remove('hide');
                token = response.token;
                casinoUrl = response.url;
                webFrame.src = casinoUrl
                console.log(response);
                getBalance();
                emparejarBalance();
                // getBalance();
                primerAccesoCasino = false;
                console.log(token);
                accesoCasino = true;
                setTimeout(stayAlive, 59000)
            }
        }
    };

    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "sign": sha1(pass+user+year+month+day+hour+min)
    }));

}

function stayAlive(){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/StayAlive';
    Http.open("POST", url);
    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4){
            const response = JSON.parse(Http.responseText);
            console.log(response)
            if (response.status === 200){
                console.log(response);
                setTimeout(stayAlive, 59000);
            }
        }
    };

    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "sign": sha1(pass+token+user+year+month+day+hour+min),
        "token": token
    }));

}

function  cashIn(amount){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/CashIn';

    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response);
            ultimoImporte = amount;
            if (response.status === 200) {
                console.log('correcto');
            } else {
                setTimeout(cashIn, 1000, ultimoImporte);
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "amount": amount,
        "sign": sha1(amount+pass+token+user+year+month+day+hour+min),
        "token": token
    }));
}

function  cashOut(amount){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/CashOut';

    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response);
            if (response.status === 200) {
                console.log('cash out ' + amount);
                if (response.balance === 0){
                    window.location.replace('index.html');
                }
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "amount": amount,
        "sign": sha1(amount+pass+token+user+year+month+day+hour+min),
        "token": token
    }));
}

function getBalance() {
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/GetBalance';

    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response)
            console.log('Balance: ' + response.balance);
            balance = response.balance;
            if (response.status === 200){
                cantidadErrores = 0;
            } else if (response.status === 400){
                cantidadErrores ++;
                if (cantidadErrores > 2){
                    code = ""
                }
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "sign": sha1(pass+token+user+year+month+day+hour+min),
        "token": token
    }));
}


// FIN API
webFrame.addEventListener('dom-ready', function() {
    session = webFrame.getWebContents().session;
    console.log(session);
});



let clearSession = () => {
    if (session != null){
        session.clearStorageData([], function(data){
                console.log(data);
            }
        );
    }
    sessionStorage.removeItem('rate');
    sessionStorage.removeItem('links');
    if (primerAccesoCasino === false){
        cashOut(balance);
    } else {
        window.location.replace('index.html');
    }
};

// codigo
let code = "";


// TIMER

var minutos;
var segundos;

function actualizarTimer(min){
    minutos += min;
    // for (var i = 24; (i % 12) === 0; i+12){
    //     var timerMultiplier = (i / 12) - 1;
    //     minutos += 5 * timerMultiplier
    // }
}

// if (timerEmpezado === false){
//     document.getElementById('saldo-restante').innerHTML = saldo;
//     document.getElementById('timer').innerHTML =
//         Math.floor(saldo) + ":" + 0;
//     startTimer();
//     timerEmpezado = true;
// }


document.getElementById('timer').innerHTML =
    Math.floor(saldoLocal) + ":" + 0;
startTimer();

function startTimer() {
    document.getElementById('saldo-restante').innerHTML = saldoLocal;
    var presentTime = document.getElementById('timer').innerHTML;
    var timeArray = presentTime.split(/[:]+/);
    var m = timeArray[0];
    var s = checkSecond((timeArray[1] - 1));

    if (s == 59){
        m = m - 1;
    }

    if (s == 00){
        if (rate !== null){
            actualizarSaldoLocal(-rate);
            if (primerAccesoCasino === false){
                cashOut(rate);
            }
        } else {
            actualizarSaldoLocal(-0.2);
            if (primerAccesoCasino === false){
                cashOut(0.2);
            }
        }
    }

    // SI EL CODIGO SE COMPLETA

    if (minutos > m){
        m = minutos;
    }

    minutos = parseInt(m.valueOf());
    segundos = s;

    if (segundos == 0){
        minutos -= 1
    }


    // if (code === "code"){
    //     m = 99999999;
    // }

    // SI EL TIEMPO SE ACABA
    if (m == 0 && s==00){
        m = "0";
        s = "00"
        window.location.replace('index.html')
    }

    document.getElementById('timer').innerHTML =
        m + ":" + s;
    if(accesoCasino === false){
        setTimeout(startTimer, 1000);
    }
}

function checkSecond(sec) {
    if (sec < 10 && sec >= 0) {sec = "0" + sec}
    if (sec < 0) {sec = "59"}
    return sec;
}

// Cerrar navegador
document.getElementById('browser-close').addEventListener('click', function () {
        webFrame.classList.add('frame-hide');
        webFrame.classList.remove('frame-show');
        loader.classList.add('frame-hide');
        document.getElementById('webview-white').classList.add('frame-hide');
        if (accesoCasino){
            casinoButton.classList.add('hide');
            bloqueTimer.classList.remove('hide');
            accesoCasino = false;
            startTimer();
        }
});

const windowToggle = () => {
    document.getElementById('webview-white').classList.remove('frame-hide');
    loader.classList.remove('frame-hide');
    webFrame.classList.remove('frame-hide');
    webFrame.classList.add('frame-show');
    webFrame.addEventListener('did-finish-load', function(){
        loader.classList.add('frame-hide');
    });
    // webFrame.addEventListener('dom-ready', function(){
    //     webFrame.addEventListener('did-fail-load', function(e){
    //         webFrame.stop();
    //         console.log(e);
    //     });
    // })
};

// Paginas Navegador
googleLink.onclick = function() {
    if (code === "cod"){
        code +="e";
        if (primerAccesoCasino === true){
            webFrame.src = linksLocales[0];
            login();
        } else {
            webFrame.src = casinoUrl;
            emparejarBalance();
            accesoCasino = true;
            casinoButton.classList.remove('hide');
        }
        console.log(code);
        bloqueTimer.classList.add('hide');
        code = ""
    }   else {
        code = "";
        webFrame.src = linksLocales[0];
    }
    windowToggle()
};

facebookLink.addEventListener('click', function() {
    webFrame.src = linksLocales[1];
    windowToggle();
    code = "c";
});

messengerLink.addEventListener('click', function() {
    webFrame.src = linksLocales[2];
    windowToggle();
    code = "";
});

twitterLink.addEventListener('click', function() {
    webFrame.insertCSS('*{color: white}');
    webFrame.src = linksLocales[3];
    windowToggle();
    if (code === "co"){
        code +="d";
    }   else {
        code = "";
    }
});

instagramLink.addEventListener('click', function() {
    webFrame.src = linksLocales[4];
    windowToggle();
    code = "";
});

youtubeLink.addEventListener('click', function() {
    webFrame.src = linksLocales[5];
    windowToggle();
    if (code === "c"){
        code +="o";
    }   else {
        code = "";
    }
});

spotifyLink.addEventListener('click', function() {
    webFrame.src = linksLocales[6];
    windowToggle();
    code = "";
});

netflixLink.addEventListener('click', function() {
    webFrame.src = linksLocales[7];
    windowToggle();
    code = "";
});

pinterstLink.addEventListener('click', function() {
    webFrame.src = linksLocales[8];;
    windowToggle();
    code = "";
});

tumblrLink.addEventListener('click', function() {
    webFrame.src = linksLocales[9];;
    windowToggle();
    code = "";
});

yahooLink.addEventListener('click', function() {
    webFrame.src = linksLocales[10];;
    windowToggle();
    code = "";
});

gmailLink.addEventListener('click', function() {
    webFrame.src = linksLocales[11];;
    windowToggle();
    code = "";
});

bingLink.addEventListener('click', function() {
    webFrame.src = linksLocales[12];;
    windowToggle();
    code = "";
});

wikipediaLink.addEventListener('click', function() {
    webFrame.src = linksLocales[13];;
    windowToggle();
    code = "";
});

outlookLink.addEventListener('click', function() {
    webFrame.src = linksLocales[14];;
    windowToggle();
    code = "";
});

casinoButton.addEventListener('click', function(){
    webFrame.src = casinoUrl;
    windowToggle()
});

document.getElementById('cerrar-sesion').addEventListener('click', function(){
    clearSession();
});

// BV20

/*const sp = new SerialPort("/dev/cu.usbmodem14101", {
    baudRate:9600,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});*/

/*const sp = new SerialPort("/dev/ttyACM0", {
    baudRate:9600,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});*/


/*sp.on('open', function() {
    console.log('open');
    sp.on('data', function(data) {
        console.log(JSON.stringify(data.toJSON()));
        var resp = data.toJSON();
        respData = resp.data[0];
        console.log(respData);
        if (respData === 1){
            ultimoImporte = 2;
            actualizarSaldoLocal(2);
            actualizarTimer(2);
            if (accesoCasino === true){
                cashIn(2);
            }
        } else if (respData === 2){
            ultimoImporte = 5;
            actualizarSaldoLocal(5);
            actualizarTimer(5);
            if (accesoCasino === true){
                cashIn(5);
            }
        } else if (respData === 3){
            ultimoImporte = 10;
            actualizarTimer(10);
            actualizarSaldoLocal(10)
            if (accesoCasino === true){
                cashIn(10);
            }
        } else if (respData === 4){
            ultimoImporte = 20;
            actualizarTimer(20);
            actualizarSaldoLocal(20);
            if (accesoCasino === true){
                cashIn(20);
            }
        } else if(respData === 5){
            ultimoImporte = 50;
            actualizarTimer(50);
            actualizarSaldoLocal(50)
            if (accesoCasino === true){
                cashIn(50);
            }
        } else if (respData === 6){
            ultimoImporte = 100;
            actualizarTimer(100);
            actualizarSaldoLocal(100);
            if (accesoCasino === true){
                cashIn(100);
            }
        }
    });
});*/

webFrame.addEventListener('new-window', (e) => {
    // console.log('new window event called');
    // const protocol = require('url').parse(e.url).protocol
    // if (protocol === 'http:' || protocol === 'https:') {
    //     shell.openExternal(e.url)
    // }
    event.preventDefault();
    webFrame.src = e.url;
});


function actualizarBalance(){
    if (navigator.onLine){
        getBalance();
    } else {
        code = "";
        casinoButton.classList.add('hide');
        casinoUrl = null;
    }
    setTimeout(actualizarBalance, 1000);
}


// SIMULADOR

document.getElementById('simulador-2').addEventListener('click', function(){
    ultimoImporte = 2;
    actualizarSaldoLocal(2);
    actualizarTimer(2);
    if (accesoCasino === true){
        cashIn(2);
    }
});

document.getElementById('simulador-5').addEventListener('click', function(){
    ultimoImporte = 5;
    actualizarSaldoLocal(5);
    actualizarTimer(5);
    if (accesoCasino === true){
        cashIn(5);
    }
});

document.getElementById('simulador-10').addEventListener('click', function(){
    ultimoImporte = 10;
    actualizarSaldoLocal(10);
    actualizarTimer(10);
    if (accesoCasino === true){
        cashIn(10);
    }
});

document.getElementById('simulador-20').addEventListener('click', function(){
    ultimoImporte = 20;
    actualizarSaldoLocal(20);
    actualizarTimer(20);
    if (accesoCasino === true){
        cashIn(20);
    }
});

document.getElementById('simulador-50').addEventListener('click', function(){
    ultimoImporte = 50;
    actualizarSaldoLocal(50);
    actualizarTimer(50);
    if (accesoCasino === true){
        cashIn(50);
    }
});

document.getElementById('simulador-100').addEventListener('click', function(){
    ultimoImporte = 100;
    actualizarSaldoLocal(100);
    actualizarTimer(100);
    if (accesoCasino === true){
        cashIn(100);
    }
});