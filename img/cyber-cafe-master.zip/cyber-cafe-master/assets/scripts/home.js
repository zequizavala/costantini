const SerialPort = require("serialport");
const sha1 = require('sha1');

let saldoRestado = false;


let saldoLocal;

window.sessionStorage.setItem('saldoLocal', '0');

saldoLocal = Number(window.sessionStorage.getItem('saldoLocal'));

function actualizarSaldoLocal(q){
    window.sessionStorage.setItem('saldoLocal', saldoLocal+=q);
    saldoLocal = Number(window.sessionStorage.getItem('saldoLocal'));
}









function checkSaldo(){
    if (saldoLocal > 1 ){
        window.location.replace("mainWindow.html");
    }
}

/*const sp = new SerialPort("/dev/cu.usbmodem14101", {
    baudRate:9600,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});*/

/*const sp = new SerialPort("/dev/ttyACM0", {
    baudRate:9600,
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    flowControl: false
});*/


/*sp.on('open', function() {
    console.log('open');
    sp.on('data', function(data) {
        console.log('data received: ', JSON.stringify(data.toJSON()));
        var resp = data.toJSON();
        respData = resp.data[0];
        console.log(respData);
        if (respData === 1){
            actualizarSaldoLocal(2);
            checkSaldo();
            console.log(saldo);
        } else if( respData === 2){
            actualizarSaldoLocal(5);
            checkSaldo();
            console.log(saldo);
        } else if( respData === 3){
            actualizarSaldoLocal(10);
            checkSaldo();
            console.log(saldo);
        } else if( respData === 4){
            actualizarSaldoLocal(20);
            checkSaldo();
            console.log(saldo);
        } else if( respData === 5) {
            actualizarSaldoLocal(50);
            checkSaldo();
            console.log(saldo);
        } else if( respData === 6){
            actualizarSaldoLocal(100);
            checkSaldo();
            console.log(saldo);
        }
    });
});*/

/*
let user = "k00m01";
let pass = "1q2w3e4r";
let token;
let casinoUrl;

function login(){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/Login';
    Http.open("POST", url);

    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4){
            const response = JSON.parse(Http.responseText);
            token = response.token;
            casinoUrl = response.url;
            console.log(response);
            getBalance();
        }
    };

    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "sign": sha1(pass+user)
    }));

}

login();

function  cashIn(amount){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/CashIn';
    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response);
            if (response.status === 200) {
                if (response.balance > 0){
                    window.location.replace("mainWindow.html");
                }
                // document.getElementById('saldo-restante').innerHTML = saldo;
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "amount": amount,
        "sign": sha1(amount+pass+token+user),
        "token": token
    }));
}

function  cashOut(amount){
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/CashOut';
    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response);
            if (response.status === "200") {
                saldo = response.balance;
                // document.getElementById('saldo-restante').innerHTML = saldo;
                saldoRestado = true;
            } else if (response.status === 400 && saldoRestado === false){
                setTimeout(cashOut, 1500, saldo)
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "amount": amount,
        "sign": sha1(amount+pass+token+user),
        "token": token
    }));
}

function getBalance() {
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/GetBalance';
    Http.open("POST", url);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response);
            saldo = response.balance;
            if (token !== undefined && saldo > 0){
                setTimeout(cashOut, 1500, saldo);
            }
        }
    };
    Http.send(JSON.stringify({
        "user": user,
        "pass": pass,
        "sign": sha1(pass+token+user),
        "token": token
    }));
}*/



// SIMULADOR

document.getElementById('simulador-2').addEventListener('click', function(){
    actualizarSaldoLocal(2);
    checkSaldo();
});

document.getElementById('simulador-5').addEventListener('click', function(){
    actualizarSaldoLocal(5);
    checkSaldo();
});

document.getElementById('simulador-10').addEventListener('click', function(){
    actualizarSaldoLocal(10);
    checkSaldo();
});

document.getElementById('simulador-20').addEventListener('click', function(){
    actualizarSaldoLocal(20);
    checkSaldo();
});

document.getElementById('simulador-50').addEventListener('click', function(){
    actualizarSaldoLocal(50);
    checkSaldo();
});

document.getElementById('simulador-100').addEventListener('click', function(){
    actualizarSaldoLocal(100);
    checkSaldo();
});


function getConfig() {
    const Http = new XMLHttpRequest();
    const url='http://ecomerciar.paladarfrio.com/Requests.php/GetConfig';
    Http.open("POST", url);

    let d = new Date();
    let year = d.getUTCFullYear().toString();
    let month = (d.getUTCMonth() + 1).toString();
    let day = d.getUTCDate().toString();
    let hour = d.getUTCHours().toString();
    let min = d.getUTCMinutes().toString();
    if (d.getUTCDate() < 10) {
        day = "0" + day;
    } else if ((d.getUTCMonth + 1) < 10) {
        month = "0" + month;
    } else if (d.getUTCMinutes() < 10) {
        min = "0" + min;
    } else if (d.getUTCHours() < 10) {
        hour = "0" + hour
    }

    console.log(year + month + day + hour + min);
    Http.onreadystatechange=(e)=>{
        if (Http.readyState == 4) {
            const response = JSON.parse(Http.responseText);
            console.log(response.config.rate);
            // console.log(response.config.icons);
            window.sessionStorage.setItem('links', JSON.stringify(response.config.icons));
            window.sessionStorage.setItem('rate', response.config.rate);
            let links = JSON.parse(window.sessionStorage.getItem('links'));
            console.log(response.config.icons);
            console.log(links)

        }
    };
    Http.send(JSON.stringify({
        "key": sha1("!"+year+month+day+hour+min)
    }));
}

getConfig();