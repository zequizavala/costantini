const electron = require('electron');
const url = require('url');
const path = require('path');
const AutoLaunch = require('auto-launch');
const {app, BrowserWindow, ipcMain} = electron;

let mainWindow;

let casinoAutoLauncher = new AutoLaunch({
    name: 'Casino'
});

casinoAutoLauncher.enable();

casinoAutoLauncher.isEnabled()
.then(function(isEnabled){
    if(isEnabled){
        return;
    }
    casinoAutoLauncher.enable();
})
.catch(function(err){
    // handle error
});

app.on('ready', function(){
    const display = electron.screen.getPrimaryDisplay();
    const maxiSize = display.workAreaSize;
    mainWindow = new BrowserWindow({
        resizable: false,
        height: maxiSize.height,
        width: maxiSize.width,
        frame: false,
        // kiosk: true
    });

    mainWindow.webContents.openDevTools();

    app.on('web-contents-created', function (webContentsCreatedEvent, contents) {
        if (contents.getType() === 'webview') {
            contents.on('new-window', function (newWindowEvent, url) {
                console.log('block');
                newWindowEvent.preventDefault();
            });
        }
    });

    // mainWindow.onbeforeunload = (e) => {
    //     e.returnValue = false;  // this will *prevent* the closing no matter what value is passed
    //
    //     if(confirm('Do you really want to close the application?')) {
    //         win.destroy();  // this will bypass onbeforeunload and close the app
    //     }
    // };

    mainWindow.loadURL(url.format({
        pathname: path.join(__dirname, './views/index.html'),
        protocol: 'file',
        slashes: true
    }));
});